# HotDemo

A dummy package built by `tools/make-dummy-package.ps1`. It carries the Progenitor HotDemo sample
plugin and a `progenitor.json` that declares `hotLoadable: true` for side `both`.

> **Requires Progenitor.** This mod is built on [Progenitor](https://thunderstore.io/c/v-rising/p/VRising_Modders/Progenitor/), a modding framework for V Rising. Mod managers install it for you; for a manual install, install Progenitor first.
Nothing here was published. The listing exists only in the local `index.json` beside this file.