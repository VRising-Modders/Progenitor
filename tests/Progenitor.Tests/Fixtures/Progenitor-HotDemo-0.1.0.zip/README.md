# HotDemo

A dummy package built by `tools/make-dummy-package.ps1`. It carries the Progenitor HotDemo sample
plugin and a `progenitor.json` that declares `hotLoadable: true` for side `both`.

Nothing here was published. The listing exists only in the local `index.json` beside this file.