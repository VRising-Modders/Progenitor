using BepInEx;
using BepInEx.Unity.IL2CPP;

namespace QStack;

/// <summary>A generated plain BepInEx plugin: it only logs that it loaded.</summary>
[BepInPlugin("qateam.qstack", "QStack", "1.0.1")]
public sealed class Plugin : BasePlugin
{
    public override void Load() => Log.LogInfo("QStack 1.0.1 loaded.");
}